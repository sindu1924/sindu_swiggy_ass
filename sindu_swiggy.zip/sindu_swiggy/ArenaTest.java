import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ArenaTest {
    @Test
    public void testFight() {
        Player playerA = new Player(50, 5, 10);
        Player playerB = new Player(100, 10, 5);
        Player winner = Arena.fight(playerA, playerB);
        assertNotNull(winner);
        assertTrue(winner.isAlive());
    }
}
