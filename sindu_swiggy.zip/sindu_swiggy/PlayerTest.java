import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PlayerTest {
    @Test
    public void testPlayerInitialization() {
        Player player = new Player(50, 5, 10);
        assertEquals(50, player.getHealth());
        assertEquals(5, player.getStrength());
        assertEquals(10, player.getAttack());
    }

    @Test
    public void testPlayerAttackAndDefend() {
        Player attacker = new Player(50, 5, 10);
        Player defender = new Player(100, 10, 5);
        attacker.attack(defender);
        assertTrue(defender.getHealth() <= 100);
    }

    @Test
    public void testPlayerDeath() {
        Player player = new Player(10, 5, 5);
        player.defend(20);
        assertFalse(player.isAlive());
    }
}
