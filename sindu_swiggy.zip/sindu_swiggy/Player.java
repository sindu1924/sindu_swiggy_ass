public class Player {
    private int health;
    private int strength;
    private int attack;

    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }

    public int getHealth() {
        return health;
    }

    public int getStrength() {
        return strength;
    }

    public int getAttack() {
        return attack;
    }

    public void attack(Player opponent) {
        int attackRoll = (int) (Math.random() * 6) + 1;
        int defendRoll = (int) (Math.random() * 6) + 1;

        int attackDamage = this.attack * attackRoll;
        int defendDamage = opponent.getStrength() * defendRoll;

        int damageDealt = attackDamage - defendDamage;
        if (damageDealt > 0) {
            opponent.defend(damageDealt);
        }
    }

    public void defend(int attackDamage) {
        this.health -= attackDamage;
        if (this.health < 0) {
            this.health = 0;
        }
    }

    public boolean isAlive() {
        return this.health > 0;
    }
}
