# Magical Arena

## Description
A simple game where two players fight until one player's health reaches zero. Each player has health, strength, and attack attributes. Players take turns attacking and defending using dice rolls to determine damage.

## How to Run

1. **Compile the code**:
   ```bash
   javac -d out src/main/java/*.java
